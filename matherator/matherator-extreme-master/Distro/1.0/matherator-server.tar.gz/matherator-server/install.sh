#!/bin/sh
MY_PATH="`dirname \"$0\"`"              # relative

mkdir -p /usr/lib/matherator
cp "$MY_PATH/data/matheratord.jar" /usr/lib/matherator/matheratord.jar
cp "$MY_PATH/data/blank.sqlite" /usr/lib/matherator/userdata.sqlite

cp "$MY_PATH/data/matheratord" /usr/bin/matheratord

chown root /usr/bin/matheratord
chmod a+x /usr/bin/matheratord
